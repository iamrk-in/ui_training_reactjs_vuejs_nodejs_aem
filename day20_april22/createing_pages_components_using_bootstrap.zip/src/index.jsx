import React from "react";
import ReactDOM from "react-dom";
import "./index.css"
import AboutUs from "./Pages/AboutUs";
import Home from "./Pages/Home";

ReactDOM.render(
    <AboutUs />, 
    document.getElementById("root")
);