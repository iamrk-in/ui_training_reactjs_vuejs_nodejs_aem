import React from "react";

let Footer = () => {
    return(
                <footer>
                    <div class="row">
                        <div class="col-lg-12">
                            <p>Copyright &copy; Your Website, year | <a href="https://html5-templates.com/" target="_blank" rel="nofollow">HTML5 Templates</a></p>
                        </div>
                    </div>
                </footer>
    );
}

export default Footer;