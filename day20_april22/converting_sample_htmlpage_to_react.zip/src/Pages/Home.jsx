import React, { Component } from "react";
import Header from "../Components/Header";

import family from "../images/family.png";
import getaways from "../images/getaways.png"; 

class App extends Component {
    render() {
        return(
            /* wrapper */
            <div className="wrapper">
                { /* header */ }
                <Header />

                { /* blog */ }
                <div class="blog">
                    <h1>A Template for Killer Website Content</h1>

                    <img src={require("./images/cruise.png")} alt="" title="" />
            
                    <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>
                    
                    <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>

                    <a href="#" class="discover"> discover more &raquo; </a>
                </div>

                { /** column wise layouts */ }
                <div class="column-layout">
                    <div class="vblog lalign">
                        <h1>A Template for Killer Website Content</h1>
            
                        <img src={family} alt="" title="" class="calign" />
                
                        <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>
                        
                        <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>
            
                        <a href="#" class="discover"> discover more &raquo; </a>
                    </div>

                    <div class="vblog ralign">
                        <h1>A Template for Killer Website Content</h1>
            
                        <img src={getaways} alt="" title="" class="calign" />
                
                        <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>
                        
                        <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>
            
                        <a href="#" class="discover"> discover more &raquo; </a>
                    </div>
                    <div class="clr"></div>
                </div>

                { /* blog */ }
                <div class="blog">
                    <h1>A Template for Killer Website Content</h1>

                    <img src={require("./images/family.png")} alt="" title="" />
            
                    <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>
                    
                    <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>

                    <a href="#" class="discover"> discover more &raquo; </a>
                </div>
            </div>
        )
    }
}

export default App;