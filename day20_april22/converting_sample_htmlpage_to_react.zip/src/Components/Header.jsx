import React from "react";

let Header = () => {
    return(
                <div class="header">
                    <div class="nav">
                        <ul>
                            <li class="listitem"><a href="#" class="navlink"> Home </a></li>
                            <li class="listitem"><a href="#" class="navlink"> About Us </a></li>
                            <li class="listitem"><a href="#" class="navlink"> Contact Us </a></li>
                        </ul>
                    </div>
                    <div class="clr"></div>
                </div>
    );
}

export default Header;