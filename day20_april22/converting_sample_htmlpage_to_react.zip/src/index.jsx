import React from "react";
import ReactDOM from "react-dom";
import "./index.css"
// import App from "./App";
import AboutUs from "./Pages/AboutUs";

ReactDOM.render(
    <AboutUs />, 
    document.getElementById("root")
);