const AccordionData = [
    {
        id: 1, 
        qn: "is there a national cartoon day?", 
        ans: "In 1990, the National Cartoonists Society proclaimed May 5th as National Cartoonists Day."
    }, 
    {
        id: 2, 
        qn: "is there a national cartoon day?", 
        ans: "In 1990, the National Cartoonists Society proclaimed May 5th as National Cartoonists Day."
    }, 
    {
        id: 3, 
        qn: "is there a national cartoon day?", 
        ans: "In 1990, the National Cartoonists Society proclaimed May 5th as National Cartoonists Day."
    }, 
    {
        id: 4, 
        qn: "is there a national cartoon day?", 
        ans: "In 1990, the National Cartoonists Society proclaimed May 5th as National Cartoonists Day."
    }
];

export default AccordionData;