import React from "react";
import AddRemoveMultipleInputFields from "./AddRemoveMultipleInputFields";

function App() {
  return(
    <AddRemoveMultipleInputFields />
  )
}

export default App;