import React, { Component } from "react";

class App extends Component {
    render() {
        let killerStyle = {
            fontSize: "16px",
            color: "#f20", 
            textDecoration: "underline"
        };

        let num1 = 4;
        let num2 = 3;

        let num3 = null;

        if(num3 != 0) {
            num3 = (<p>Over the years of <span style={killerStyle}> developing websites </span> for clients, Ive learned that the age-old adage, If you want it done right, you gotta do it yourself, can be a two-way street.</p>);
        } else {
            num3 = (<h4>A Template for <span style={killerStyle}> Killer Website </span> Content</h4>);
        }

        return(
            <div className="wrapper">
                
                <p>num3 : {num1 ** num2}</p>
                
                <p>{num3}</p>
            </div>
        )
    }
}

export default App;