import React from "react";
import { render } from "react-dom";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// components
import Footer from "./Components/Footer";
import Header from "./Components/Header";
import LeftPanel from "./Components/LeftPanel";

// pages
import Home from "./Pages/Home/Home";
import FormValidation from "./Pages/FormValidation/FormValidation";
import FileUpload from "./Pages/FileUpload/FileUpload";
import Refs from "./Pages/Refs/Refs";
import RestApi from "./Pages/RestApi/RestApi";

import "./styles.css";
import TodoApp from "./Pages/TodoApp/TodoApp";

const routing = (
    <Router>
    <div className="container">
        <Header />
        
        <div className="row">
            <LeftPanel />

            <div class="col-sm-9">
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/form-validation" element={<FormValidation />} />
                    <Route path="/file-upload" element={<FileUpload />} />
                    <Route path="/ref" element={<Refs />} />
                    <Route path="/restapi" element={<RestApi />} />
                    <Route path="/todoapp" element={<TodoApp />} />
                </Routes>
            </div>
        </div>

        <Footer />
    </div>
    </Router>
);

const container = document.createElement("div");
document.body.appendChild(container);
render(routing, container);