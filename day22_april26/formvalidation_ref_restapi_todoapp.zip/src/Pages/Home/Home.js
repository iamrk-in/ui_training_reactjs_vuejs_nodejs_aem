import React, { Component } from "react";

class Home extends Component {
  render() {
    return(
      <div className="row">
        <div className="col-12">
          <h4>Home</h4>

          <p>this is Home!</p>
        </div>
      </div>
    );
  }
}

export default Home;