import React from "react";

class TodoList extends React.Component {
    render() {
        return(
            <ul className="list-group list-group-flush">
                <li className="list-group-item bg-light d-flex justify-content-between">
                AirTran Airways (IATA airline code), defunct American airline
                    <button type="button" className="btn btn-danger text-danger-badge">&times;</button>
                </li>
                <li className="list-group-item bg-light d-flex justify-content-between">
                Foot Locker (ticker symbol), retailer
                    <button type="button" className="btn btn-danger text-danger-badge">&times;</button>
                </li>
                <li className="list-group-item bg-light d-flex justify-content-between">
                Guilder, various coins also sometimes called "florin"
                    <button type="button" className="btn btn-danger text-danger-badge">&times;</button>
                </li>
            </ul>
        )
    }
}

export default TodoList;