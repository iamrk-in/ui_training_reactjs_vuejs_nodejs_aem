import React from "react";
import { NavLink } from "react-router-dom";

let Header = () => {
    return(
            <div class="row header">
                <div class="col-sm-3">
                    <h3>Responsive Website</h3>
                </div>

                <div class="col-sm-9 text-sm-end">
                    <NavLink activeClassName="active" className="text-dark" to="/"> home </NavLink>
                    <span> | </span>
                    <NavLink activeClassName="active" className="text-dark" to="/form-validation"> form validation </NavLink>
                    <span> | </span>
                    <NavLink activeClassName="active" className="text-dark" to="/file-upload"> file upload </NavLink>
                    <span> | </span>
                    <NavLink activeClassName="active" className="text-dark" to="/ref"> ref </NavLink>
                    <span> | </span>
                    <NavLink activeClassName="active" className="text-dark" to="/restapi"> restapi </NavLink>
                    <span> | </span>
                    <NavLink activeClassName="active" className="text-dark" to="/todoapp"> todoapp </NavLink>
                </div>
            </div>
    );
}

export default Header;