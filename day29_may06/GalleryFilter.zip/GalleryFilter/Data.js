const data =[
    {
        id:1,
        image:"./images/",
        title:"HTML Tutoril",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"frontend",
       
    },
    {
        id:2,
        image:"./images/",
        title:"CSS Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"frontend",
       
    },
    {
        id:3,
        image:"./images/",
        title:"JS Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"frontend",
       
    },
    {
        id:4,
        image:"./images/",
        title:"React Js Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"frontend",
       
    },
    {
        id:5,
        image:"./images/",
        title:"Bootstrap Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"frontend",
       
    },
    {
        id:6,
        image:"./images/",
        title:"PHP Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"backend",
       
    },
    {
        id:7,
        image:"./images/",
        title:"Node.js Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"backend",
       
    },
    {
        id:8,
        image:"./images/",
        title:"ASP Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"backend",
       
    },
    {
        id:9,
        image:"./images/",
        title:"SQL Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"database",
       
    },
    {
        id:10,
        image:"./images/",
        title:"Mongo DB Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"database",
       
    },
    {
        id:11,
        image:"./images/",
        title:"C Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"programming",
       
    },
    {
        id:12,
        image:"./images/",
        title:"C++ Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"programming",
       
    },
    {
        id:13,
        image:"./images/",
        title:"Java Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"programming",
       
    },
    {
        id:14,
        image:"./images/",
        title:"Python Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
        category:"programming",
       
    },
    {
        id:15,
        image:"./images/",
        title:"Go Tutorial",
        description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        category:"programming",
       
    },
]

export default data;