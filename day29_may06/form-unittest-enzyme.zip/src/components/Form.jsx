import React from "react";
import TextInput from "./TextInput";

class Form extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            firstname: 'hello', 
            // lastname: '', 
            // emailaddress: '', 
            // languages: [], 
            // subscribed: false
        }
    }

    render() {
        // let languages = ['english', 'spanish', 'germany', 'japanes'];
        return(
            <form name="frm" onSubmit={this.handleSubmit}>
                <TextInput labelFor="firstname" label="firstname" className="form-control" type="text" name="firstname" id="firstname" value={this.state.firstname} handleChange={this.handleChange} />

                {/* <TextInput labelFor="lastname" label="lastname" className="form-control" type="text" name="lastname" id="lastname" value={this.state.lastname} handleChange={this.handleChange} />

                <TextInput labelFor="emailaddress" label="emailaddress" className="form-control" type="text" name="emailaddress" id="emailaddress" value={this.state.emailaddress} handleChange={this.handleChange} />

                <MultiSelect labelFor="languages" label="languages" className="form-control" value={this.state.languages} handleChange={this.handleMultiSelect} >
                    <Options options={languages} />
                </MultiSelect>

                <Checkbox labelFor="subscribed" label="subscribed" handleChange={this.handleChange} Checked={this.state.subscribed} />               
                
                <Button type="submit" className="btn btn-primary"> submit </Button> */}
            </form>
        )
    }
}


export default Form;