import React from "react";

const Jumbotron = (props) => {
    return(
        <div className="jumbotron">
            {props.chilren}
        </div>
    )
}

export default Jumbotron;