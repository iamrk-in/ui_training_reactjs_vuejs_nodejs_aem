import React from "react";
import renderer from "react-test-renderer";

import { mount } from "enzyme";
import enzymeConfig from "../../enzymeConfig";
import Form from "../components/Form";

describe("Container", function() {
    
    it("should render correctly", function() {
        const tree = renderer.create(<Form />).toJSON();
        expect(tree).toMatchSnapshot();
    });

    
    it("should capture firstname correctly onChange", function() {
        const component = mount(<Form />);
        const input = component.find('input').at(0);
        input.instance().value = 'hello';
        input.simulate('change');
        expect(component.state().firstname).toEqual('hello');
    })

});