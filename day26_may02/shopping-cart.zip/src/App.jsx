import React, { Component } from "react";
import MyCart from "./MyCart";

export default class App extends Component {
    render() {
        return(
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        { /* MyCart */ }
                        <MyCart />
                    </div>
                </div>
            </div>
        );
    }
}